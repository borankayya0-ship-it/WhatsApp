package com.voip.fakecall
import android.content.Context
import org.webrtc.*

class RTCClient(
    private val context: Context,
    private val signaling: SignalingClient,
    private val myId: String,
    private val remoteId: String,
    private val listener: Listener
) {
    interface Listener {
        fun onIceCandidate(sdpMid: String?, sdpMLineIndex: Int, sdp: String)
        fun onConnectionChange(state: String)
    }
    private val eglBase = EglBase.create()
    private var factory: PeerConnectionFactory
    private var peerConnection: PeerConnection? = null
    private var localAudioTrack: AudioTrack? = null

    init {
        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(context).createInitializationOptions())
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglBase.eglBaseContext))
            .createPeerConnectionFactory()
    }

    private fun createPeerConnection() {
        val iceServers = listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
        )
        val config = PeerConnection.RTCConfiguration(iceServers).apply { sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN }
        peerConnection = factory.createPeerConnection(config, object : PeerConnection.Observer {
            override fun onIceCandidate(c: IceCandidate?) {
                c?.let {
                    listener.onIceCandidate(it.sdpMid, it.sdpMLineIndex, it.sdp)
                    signaling.sendIceCandidate(remoteId, myId, it.sdpMid, it.sdpMLineIndex, it.sdp)
                }
            }
            override fun onConnectionChange(newState: PeerConnection.PeerConnectionState?) { listener.onConnectionChange(newState?.name ?: "UNKNOWN") }
            override fun onIceConnectionChange(p0: PeerConnection.IceConnectionState?) {}
            override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}
            override fun onIceConnectionReceivingChange(p0: Boolean) {}
            override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}
            override fun onAddStream(p0: MediaStream?) {}
            override fun onRemoveStream(p0: MediaStream?) {}
            override fun onDataChannel(p0: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(p0: RtpReceiver?, p1: Array<out MediaStream>?) {}
        })
        val audioSource = factory.createAudioSource(MediaConstraints())
        localAudioTrack = factory.createAudioTrack("101", audioSource)
        localAudioTrack?.setEnabled(true)
        peerConnection?.addTrack(localAudioTrack, listOf("local"))
    }

    fun call() {
        createPeerConnection()
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
        }
        peerConnection?.createOffer(object : SdpObserver, SdpObserver by SdpObserverAdapter() {
            override fun onCreateSuccess(desc: SessionDescription?) {
                desc?.let { peerConnection?.setLocalDescription(SdpObserverAdapter(), it); signaling.sendOffer(remoteId, myId, it.description) }
            }
        }, constraints)
    }

    fun onRemoteOfferReceived(sdp: String) {
        createPeerConnection()
        val remoteDesc = SessionDescription(SessionDescription.Type.OFFER, sdp)
        peerConnection?.setRemoteDescription(SdpObserverAdapter(), remoteDesc)
        peerConnection?.setLocalDescription(SdpObserverAdapter(), remoteDesc)
        val constraints = MediaConstraints().apply { mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true")) }
        peerConnection?.createAnswer(object : SdpObserver, SdpObserver by SdpObserverAdapter() {
            override fun onCreateSuccess(desc: SessionDescription?) {
                desc?.let { peerConnection?.setLocalDescription(SdpObserverAdapter(), it); signaling.sendAnswer(remoteId, myId, it.description) }
            }
        }, constraints)
    }

    fun onRemoteAnswerReceived(sdp: String) {
        val remoteDesc = SessionDescription(SessionDescription.Type.ANSWER, sdp)
        peerConnection?.setRemoteDescription(SdpObserverAdapter(), remoteDesc)
    }

    fun addIceCandidate(sdpMid: String?, sdpMLineIndex: Int, sdp: String) {
        peerConnection?.addIceCandidate(IceCandidate(sdpMid, sdpMLineIndex, sdp))
    }

    fun endCall() { localAudioTrack?.setEnabled(false); peerConnection?.close(); peerConnection = null }

    open class SdpObserverAdapter : SdpObserver {
        override fun onCreateSuccess(desc: SessionDescription?) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(msg: String?) {}
        override fun onSetFailure(msg: String?) {}
    }
}