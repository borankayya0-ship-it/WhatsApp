package com.voip.fakecall
import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {
    private val signaling = SignalingClient()
    private var rtcClient: RTCClient? = null
    private var myFakeNumber by mutableStateOf("")
    private var remoteFakeNumber by mutableStateOf("")
    private var callState by mutableStateOf("Hazir")
    private var inCall by mutableStateOf(false)

    private val requestPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (!isGranted) Toast.makeText(this, "Mikrofon izni gerekli!", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        checkMicPermission()
        setContent { MaterialTheme { VoipScreen() } }
    }

    @Composable
    fun VoipScreen() {
        val context = LocalContext.current
        var myIdInput by remember { mutableStateOf("") }
        var remoteIdInput by remember { mutableStateOf("") }
        var listening by remember { mutableStateOf(false) }

        LaunchedEffect(myFakeNumber, listening) {
            if (myFakeNumber.isNotEmpty() && listening) {
                signaling.observeIncomingCalls(myFakeNumber).collectLatest { call ->
                    if (call.type == "OFFER" && !inCall) {
                        remoteFakeNumber = call.from
                        callState = call.from + " ariyor..."
                        rtcClient = RTCClient(context, signaling, myFakeNumber, call.from, object : RTCClient.Listener {
                            override fun onIceCandidate(sdpMid: String?, sdpMLineIndex: Int, sdp: String) {}
                            override fun onConnectionChange(state: String) { callState = state }
                        })
                        rtcClient?.onRemoteOfferReceived(call.sdp)
                        observeIce(call.from)
                        inCall = true
                        callState = "Baglandi - " + call.from + " ile konusuyorsun"
                    } else if (call.type == "ANSWER" && inCall) {
                        rtcClient?.onRemoteAnswerReceived(call.sdp)
                        callState = "Baglandi - " + call.from + " ile konusuyorsun"
                    }
                }
            }
        }

        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("FakeCall VoIP - Profesyonel", style = MaterialTheme.typography.headlineSmall)
            Text("Durum: " + callState)
            Divider()
            OutlinedTextField(value = myIdInput, onValueChange = { myIdInput = it }, label = { Text("Kendi Sahte Numaran (orn: 5551112233)") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                if (myIdInput.length < 7) { Toast.makeText(context, "En az 7 haneli sahte numara gir", Toast.LENGTH_SHORT).show() }
                else { myFakeNumber = myIdInput; listening = true; callState = "Online: " + myFakeNumber; Toast.makeText(context, "Giris yapildi: " + myFakeNumber, Toast.LENGTH_SHORT).show() }
            }, modifier = Modifier.fillMaxWidth()) { Text("GIRIS YAP VE ONLINE OL") }

            if (myFakeNumber.isNotEmpty()) {
                Divider()
                OutlinedTextField(value = remoteIdInput, onValueChange = { remoteIdInput = it }, label = { Text("Arkadasinin Sahte Numarasi") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { remoteFakeNumber = remoteIdInput; startCall(remoteIdInput) }, modifier = Modifier.fillMaxWidth(), enabled = !inCall) { Text("ARA - " + remoteIdInput) }
                Button(onClick = { endCall() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error), enabled = inCall) { Text("KAPAT") }
                Spacer(Modifier.height(10.dp))
                Text("Nasil kullanilir: 1. Ikiniz de ayni uygulama ile giris yapin 2. Kendi WiFi'na bagli kal 3. Birbirinizin sahte numarasini yazip ARA deyin 4. Ses dogrudan internetten gider", style = MaterialTheme.typography.bodySmall)
            }
        }
    }

    private fun startCall(to: String) {
        if (myFakeNumber.isEmpty()) return
        rtcClient = RTCClient(this, signaling, myFakeNumber, to, object : RTCClient.Listener {
            override fun onIceCandidate(sdpMid: String?, sdpMLineIndex: Int, sdp: String) {}
            override fun onConnectionChange(state: String) { runOnUiThread { callState = state } }
        })
        rtcClient?.call(); observeIce(to); inCall = true; callState = to + " araniyor..."
    }

    private fun observeIce(from: String) {
        CoroutineScope(Dispatchers.IO).launch {
            signaling.observeIceCandidates(myFakeNumber, from).collectLatest { (mid, idx, sdp) -> rtcClient?.addIceCandidate(mid, idx, sdp) }
        }
    }

    private fun endCall() { rtcClient?.endCall(); signaling.clearCall(myFakeNumber, remoteFakeNumber); inCall = false; callState = "Gorusme bitti" }
    private fun checkMicPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }
}