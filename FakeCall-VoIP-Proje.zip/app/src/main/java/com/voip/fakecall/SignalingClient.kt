package com.voip.fakecall
import com.google.firebase.database.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow

data class CallData(val type: String = "", val sdp: String = "", val from: String = "")

class SignalingClient {
    private val db = FirebaseDatabase.getInstance().reference
    fun observeIncomingCalls(myFakeNumber: String) = callbackFlow {
        val ref = db.child("calls").child(myFakeNumber)
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    for (child in snapshot.children) {
                        val type = child.child("type").getValue(String::class.java) ?: continue
                        val sdp = child.child("sdp").getValue(String::class.java) ?: ""
                        val from = child.child("from").getValue(String::class.java) ?: ""
                        trySend(CallData(type, sdp, from))
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        ref.addValueEventListener(listener)
        awaitClose { ref.removeEventListener(listener) }
    }
    fun observeIceCandidates(myFakeNumber: String, from: String) = callbackFlow {
        val ref = db.child("ice").child(myFakeNumber).child(from)
        val listener = object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, prev: String?) {
                val sdpMid = snapshot.child("sdpMid").getValue(String::class.java)
                val sdpMLineIndex = snapshot.child("sdpMLineIndex").getValue(Int::class.java) ?: 0
                val sdp = snapshot.child("sdp").getValue(String::class.java)
                if (sdpMid != null && sdp != null) trySend(Triple(sdpMid, sdpMLineIndex, sdp))
            }
            override fun onChildChanged(s: DataSnapshot, p: String?) {}
            override fun onChildRemoved(s: DataSnapshot) {}
            override fun onChildMoved(s: DataSnapshot, p: String?) {}
            override fun onCancelled(e: DatabaseError) {}
        }
        ref.addChildEventListener(listener)
        awaitClose { ref.removeEventListener(listener) }
    }
    fun sendOffer(to: String, from: String, sdp: String) {
        db.child("calls").child(to).child(from).setValue(mapOf("type" to "OFFER", "sdp" to sdp, "from" to from))
    }
    fun sendAnswer(to: String, from: String, sdp: String) {
        db.child("calls").child(to).child(from).setValue(mapOf("type" to "ANSWER", "sdp" to sdp, "from" to from))
    }
    fun sendIceCandidate(to: String, from: String, sdpMid: String?, sdpMLineIndex: Int, sdp: String) {
        db.child("ice").child(to).child(from).push().setValue(mapOf("sdpMid" to sdpMid, "sdpMLineIndex" to sdpMLineIndex, "sdp" to sdp))
    }
    fun clearCall(myFakeNumber: String, other: String) {
        db.child("calls").child(myFakeNumber).child(other).removeValue()
        db.child("ice").child(myFakeNumber).child(other).removeValue()
        db.child("calls").child(other).child(myFakeNumber).removeValue()
        db.child("ice").child(other).child(myFakeNumber).removeValue()
    }
}